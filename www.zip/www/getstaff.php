?php

$


{employeeNumber, firstName, lastName, officeCode, extension, email, jobTitle and reportsTo}.